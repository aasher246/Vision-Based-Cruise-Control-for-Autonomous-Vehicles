# import libraries
from PIL import ImageGrab
import cv2
import numpy as np
import time
import pyautogui
def mean(list):
    """
    calculate mean of list
    """
    return float(sum(list)) / max(len(list), 1)



def draw_lines(img, lines, color=[0, 255, 255], thickness=3): 

    # initialize lists to hold line formula values
    bLeftValues     = []  # b of left lines
    bRightValues    = []  # b of Right lines
    mPositiveValues = []  # m of Left lines
    mNegitiveValues = []  # m of Right lines
    
    for line in lines:
        for x1,y1,x2,y2 in line:
            cv2.line(img, (x1, y1), (x2, y2), color, thickness)
            
            # calculate slope and intercept
            m = (y2-y1)/(x2-x1)
            b = y1 - x1*m
            
            # threshold to check for outliers
            if m >= 0 and (m < 0.2 or m > 0.8):
                continue
            elif m < 0 and (m < -0.8 or m > -0.2):
                continue
                
            # seperate positive line and negative line slopes
            if m > 0:
                mPositiveValues.append(m)
                bLeftValues.append(b)
            else:
                mNegitiveValues.append(m)
                bRightValues.append(b)
    
    # Get image shape and define y region of interest value
    imshape = img.shape
    y_max   = imshape[0] # lines initial point at bottom of image    
    y_min   = 330        # lines end point at top of ROI

    # Get the mean of all the lines values
    AvgPositiveM = mean(mPositiveValues)
    AvgNegitiveM = mean(mNegitiveValues)
    AvgLeftB     = mean(bLeftValues)
    AvgRightB    = mean(bRightValues)

    # use average slopes to generate line using ROI endpoints
    if AvgPositiveM != 0:
        x1_Left = (y_max - AvgLeftB)/AvgPositiveM
        y1_Left = y_max
        x2_Left = (y_min - AvgLeftB)/AvgPositiveM
        y2_Left = y_min
    if AvgNegitiveM != 0:
        x1_Right = (y_max - AvgRightB)/AvgNegitiveM
        y1_Right = y_max
        x2_Right = (y_min - AvgRightB)/AvgNegitiveM
        y2_Right = y_min

        # define average left and right lines
        cv2.line(img, (int(x1_Left), int(y1_Left)), (int(x2_Left), int(y2_Left)), color, thickness) #avg Left Line
        cv2.line(img, (int(x1_Right), int(y1_Right)), (int(x2_Right), int(y2_Right)), color, thickness) #avg Right Line
def required_region(image, vertices):
    
    mask = np.zeros_like(image) # black image        
    cv2.fillPoly(mask, vertices, 255) # fill within vertices
    masked = cv2.bitwise_and(image, mask) # intersection of mask and image
    
    return masked


vertices = np.array([[120,500],[120,400],[150,330],\
                     [650,330],[680,400],[680,500],\
                     [260,500],[260,450],[325,370],\
                     [475,370], [540,450],[540,500]], np.int32)		
def overlay_lines(image, lines):
    
    for line in lines:
        coordinates = line[0]
        cv2.line(image,(coordinates[0],coordinates[1]),(coordinates[2],coordinates[3]),[255,255,255],3)
		
def edgeprocessed(image):
    
    original_image = image
    
    gray_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)    
    edgeprocessed_img = cv2.Canny(gray_image, threshold1 = 200, threshold2 = 300)    
    edgeprocessed_img = cv2.GaussianBlur(edgeprocessed_img,(5,5),0)    
    edgeprocessed_img = required_region(edgeprocessed_img, [vertices])    
    lines = cv2.HoughLinesP(edgeprocessed_img, 1, np.pi/180, 180, np.array([]), 100, 5)
    #overlay_lines(edgeprocessed_img, lines)
    
    m1 = 0
    m2 = 0
    
    try:
        l1, l2, m1, m2 = draw_lines(original_image,lines)
        cv2.line(original_image, (l1[0], l1[1]), (l1[2], l1[3]), [0,255,0], 30)
        cv2.line(original_image, (l2[0], l2[1]), (l2[2], l2[3]), [0,255,0], 30)
    
    except Exception as e:
        pass
    
    try:
        for coords in lines:
            coords = coords[0]
            try:
                cv2.line(edgeprocessed_img, (coords[0], coords[1]), (coords[2], coords[3]), [255,0,0], 2)
                
                
            except Exception as e:
                print(str(e))
    except Exception as e:
        pass

    return edgeprocessed_img,original_image, m1, m2
		
def screen_capture(processing = None): 
    # takes in a list for type of processing
    # [processing_function, masking_function]    
    last_time = time.time()
    
    while True:
        
        screen = np.array(ImageGrab.grab(bbox=(0,40,800,700)))        
        count = 0
            
        if processing is not None:
            
            for i in processing:
                count += 1
            
            processed_screen ,original_image, m1, m2 = processing[0](screen)

            if count > 1:      
                
                masked_screen = processing[1](processed_screen, [vertices])
                screen_1 = masked_screen
                
            else:
                
                screen_1 = processed_screen
    
        else:
            
            screen_1 = screen                
        
        cv2.imshow('Python Window 2', screen_1)
        cv2.imshow('Python Window', cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB))                
                
        print(f'the screen rate is {(1/(time.time()-last_time))}')
        last_time = time.time()
         
        if cv2.waitKey(25) & 0xFF == ord('q'):
            cv2.destroyAllWindows()
            break


screen_capture([edgeprocessed])
