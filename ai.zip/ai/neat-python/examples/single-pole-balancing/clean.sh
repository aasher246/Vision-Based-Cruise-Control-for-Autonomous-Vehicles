#!/usr/bin/env bash
rm *.svg *.gv *.mp4 winner-*